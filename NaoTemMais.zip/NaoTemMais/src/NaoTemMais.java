
import javax.swing.JFrame;

public class NaoTemMais {
     public static void main(String[] args) {
        
        Babel torredebabel = new Babel();
        torredebabel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        torredebabel.setSize(260, 180);
        torredebabel.setVisible(true);
        
    }
    
}
